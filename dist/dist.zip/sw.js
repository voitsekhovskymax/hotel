importScripts('/_nuxt/workbox.4c4f5ca6.js')

workbox.precaching.precacheAndRoute([
  {
    "url": "/_nuxt/03136974155795733f90.js",
    "revision": "5704e92157161549ffa6a9ca83a1417c"
  },
  {
    "url": "/_nuxt/067a67bcbb5cefa43fff.js",
    "revision": "01f04376b340a1eaa4679bf0fff93025"
  },
  {
    "url": "/_nuxt/08c0de0b0deb2c61f6bb.js",
    "revision": "33a8b4da9e549fd8b24d9ebcc84918ee"
  },
  {
    "url": "/_nuxt/0abcb468d83e78a9c6df.js",
    "revision": "22c6bd7b325e55c0931c280601692709"
  },
  {
    "url": "/_nuxt/0bd3d8d43e92f1910142.js",
    "revision": "ba5a2b9d267830fd00dd0ca1e8b03330"
  },
  {
    "url": "/_nuxt/147741a1094f6a9004a9.js",
    "revision": "1fd37c443eb945296e2f2311049ebca2"
  },
  {
    "url": "/_nuxt/1eebbb648982978855ac.js",
    "revision": "599e2e39af530efdc0b51774177f31da"
  },
  {
    "url": "/_nuxt/1f16d887f341ddc074e9.js",
    "revision": "d43d71f93594505992595bdc430a585d"
  },
  {
    "url": "/_nuxt/2e42df7052048b11b80b.js",
    "revision": "f43657db68f9bbfd0e9b7ea16145e33f"
  },
  {
    "url": "/_nuxt/2e80728fae71633295da.js",
    "revision": "d116089aec219be3a479351202cb5042"
  },
  {
    "url": "/_nuxt/30825d4ba31d002443e6.js",
    "revision": "005b448ef0155a345f48c07b1e163d2a"
  },
  {
    "url": "/_nuxt/339f68c1efc44fdb6640.js",
    "revision": "b0bf6ae676bd0041dc62c75f3286da50"
  },
  {
    "url": "/_nuxt/345466ec03b7d7b0f756.js",
    "revision": "a9ec74dd1541316eb770ee09183083f7"
  },
  {
    "url": "/_nuxt/353cdb6573d255f615ad.js",
    "revision": "939a9199dbb61d9cf0dc2725bf88c131"
  },
  {
    "url": "/_nuxt/392c00ed635d545bf4d1.js",
    "revision": "5817b0ec6d928f472674f2bd193a430d"
  },
  {
    "url": "/_nuxt/45200f2d73ae4e9ee3f5.js",
    "revision": "edb0483f347eb88a283de041cc698270"
  },
  {
    "url": "/_nuxt/4822d1a88bdd71bd5601.js",
    "revision": "a6b289316cdc92cacf8149bd5195ee7b"
  },
  {
    "url": "/_nuxt/48d546d7b5583591fc5b.js",
    "revision": "3dcb97580320960e572801071def0667"
  },
  {
    "url": "/_nuxt/514f84493a0d22178c48.js",
    "revision": "242efa8e1a19dbbf641f03c2cf2421d8"
  },
  {
    "url": "/_nuxt/54e16860455be64ec813.js",
    "revision": "d92fcef20daeb75a5d4561bf2e6f791d"
  },
  {
    "url": "/_nuxt/62ac4d5cf166a2dc8fc9.css",
    "revision": "cc35439ff1aec1ac6e229cc8afb9d8c2"
  },
  {
    "url": "/_nuxt/631356c6a7761b0dc8d6.js",
    "revision": "5a45dbf93d0a51b35fb9a436ad002299"
  },
  {
    "url": "/_nuxt/781f64baded1c5bedfb8.js",
    "revision": "c6f0b04f02d1ba59ae6a691417e215d5"
  },
  {
    "url": "/_nuxt/78b260e088ceea490ae9.css",
    "revision": "613b8156d4f9536f935407964fd15192"
  },
  {
    "url": "/_nuxt/7acbb2a57914925dae99.js",
    "revision": "dd6be3b83daf9d33c190407ae47b84b8"
  },
  {
    "url": "/_nuxt/7cd70acf67ec7304a58f.js",
    "revision": "3d4efe6e9cbdf13e6c0b14ecc89b6a3b"
  },
  {
    "url": "/_nuxt/7e1181343e12c17f3662.js",
    "revision": "2d834c2a6924de46135cd496fc8f166e"
  },
  {
    "url": "/_nuxt/9394f6f56739bc999d84.js",
    "revision": "75cd29632a1c30fcb60d416009eff8e7"
  },
  {
    "url": "/_nuxt/98b4bd72500ed015c31c.js",
    "revision": "eb346af67d6ade32805d25b5764ae920"
  },
  {
    "url": "/_nuxt/a14513ddc2a671d4ddfb.js",
    "revision": "f26feac17d2a54c3008a51eaad86774d"
  },
  {
    "url": "/_nuxt/b13f7c46ba0dd989725c.css",
    "revision": "cc6d8f00b56bdc5ff4d5f6cdcadb3b4a"
  },
  {
    "url": "/_nuxt/b1f9b31553ed54699ddc.js",
    "revision": "c31acef4f06cd19716aec6da93da74d3"
  },
  {
    "url": "/_nuxt/b91c0f26579555c511ef.js",
    "revision": "b4d97cebbf27e8e7e40ed28ceb0e76c6"
  },
  {
    "url": "/_nuxt/ba3e251313775d71b30e.js",
    "revision": "b90f6ae74416d94ff0d39b636516a85d"
  },
  {
    "url": "/_nuxt/bd3b77014782c5f9ed4a.js",
    "revision": "1e9e1e1f2dcb78f12e8db555d2d890d2"
  },
  {
    "url": "/_nuxt/bf144e1966a0e464216f.js",
    "revision": "28a7817b11ea7879df13ca3a53e969ab"
  },
  {
    "url": "/_nuxt/c252c908de8fb1dee6fc.css",
    "revision": "476028ad4ecc522fb96be829156350b4"
  },
  {
    "url": "/_nuxt/c5ba8f0fe52be266a9f7.js",
    "revision": "594915070c98bb78f674b46b7e09fe61"
  },
  {
    "url": "/_nuxt/c626208447dacdd28820.js",
    "revision": "6a8c1a2329f5cf5f54af7a4d93a08ddb"
  },
  {
    "url": "/_nuxt/ca7f8523c0efb8915eed.js",
    "revision": "a1cce6cd819ca1f5ff8dce4f929771cb"
  },
  {
    "url": "/_nuxt/cb440c17fd4fe2c7f0e8.js",
    "revision": "e96e7cc8b5e7a8b41fc00b990af3b8e4"
  },
  {
    "url": "/_nuxt/cdae8cdbc9df40b8e0ad.js",
    "revision": "c34cf8b777f6f5074797ab427f4d7614"
  },
  {
    "url": "/_nuxt/d1ff2f2d1ea88c4f6a2d.js",
    "revision": "524cec5713dd79bbc5d88733eb2043c6"
  },
  {
    "url": "/_nuxt/e18a16ac268209a4a5bc.js",
    "revision": "79c5656f549f720c51a141eb6c853a22"
  },
  {
    "url": "/_nuxt/e51488b3db283f49a0f9.js",
    "revision": "68248e5710d6595e2793ce865a5e1473"
  },
  {
    "url": "/_nuxt/e57f5ec6cc376cb04479.js",
    "revision": "fa31ba27fa638a2850ffdc64a0bb25fe"
  },
  {
    "url": "/_nuxt/e78cb9fbe9fa027d015e.js",
    "revision": "c43db8414f74bd2a4274c3a061d29760"
  },
  {
    "url": "/_nuxt/f1421e524ce6fe49548c.js",
    "revision": "26e51769d436261c863e7effa44f9b2b"
  },
  {
    "url": "/_nuxt/f2e5842ec6cf67ebabf5.js",
    "revision": "97d089b76665abfdcd91a38545930d55"
  },
  {
    "url": "/_nuxt/f3f5f840a5f09a730e33.js",
    "revision": "1a7bdc141b30789e82ed119866006098"
  },
  {
    "url": "/_nuxt/f42baa3cea56aa9cf18f.js",
    "revision": "b7bc537f946f85da671f68c8c241b04a"
  },
  {
    "url": "/_nuxt/fa8cc7ce11fe22ee33c6.js",
    "revision": "ea164317193d8714654ca01ff537f753"
  },
  {
    "url": "/_nuxt/ff167886019e7d708147.css",
    "revision": "613b8156d4f9536f935407964fd15192"
  }
], {
  "cacheId": "hotel-pwa",
  "directoryIndex": "/",
  "cleanUrls": false
})

workbox.clientsClaim()
workbox.skipWaiting()

workbox.routing.registerRoute(new RegExp('/_nuxt/.*'), workbox.strategies.cacheFirst({}), 'GET')

workbox.routing.registerRoute(new RegExp('/.*'), workbox.strategies.networkFirst({}), 'GET')
